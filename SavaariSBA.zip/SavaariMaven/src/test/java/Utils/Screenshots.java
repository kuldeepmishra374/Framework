package Utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshots {
public void Screenshot(WebDriver driver) throws IOException
{
	 File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE); //Screenshot to capture the result page
	 FileUtils.copyFile(src,new File("./ScreenshotPage/Savaari.png"));
}
}
