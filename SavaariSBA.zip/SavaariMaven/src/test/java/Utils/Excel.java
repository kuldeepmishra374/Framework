package Utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	public static String getValue1() throws IOException
	{
	FileInputStream f = new FileInputStream("./DataSavaari/SavaariReadData.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook(f);
	XSSFSheet sh = wb.getSheet("sheet1");
	String value1 = sh.getRow(0).getCell(0).getStringCellValue();
	System.out.println("The value in the excel sheet is:" +value1);

	   wb.close();
	   return value1;
	}

	public static String getValue2() throws IOException
	{
	FileInputStream f = new FileInputStream("./DataSavaari/SavaariReadData.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook(f);
	XSSFSheet sh = wb.getSheet("sheet1");
	String value2 = sh.getRow(1).getCell(0).getStringCellValue();
	System.out.println("The value in the excel sheet is:" +value2);

	   wb.close();
	   return value2;
	}

}
