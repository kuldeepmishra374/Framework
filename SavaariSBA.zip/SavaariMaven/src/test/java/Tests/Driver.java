package Tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import DriverSetup.BrowserSetUp;
import Library.StandardLibrary;
import Library.TestLibrary;
import Utils.Screenshots;


public class Driver {
	//Object for all the method libraries are created.
	BrowserSetUp b1 = new BrowserSetUp();
	StandardLibrary s1 = new StandardLibrary();
	TestLibrary t1 = new TestLibrary();
	Screenshots sc1 = new Screenshots();
	WebDriver driver;
	
		
	@BeforeMethod
	public void f1() throws IOException
	{
		driver = b1.driverSetup();   //For choosing the browser 
		s1.invoke(driver);        //Invoking the page
		driver.manage().deleteAllCookies();   //Deleting the browser cookies
		driver.manage().window().maximize();   //This method is used to maximize the current browser.
	}
	
	@Test
	public void f2() throws IOException, InterruptedException
	{
		t1.OneWay(driver);
		t1.FromTo(driver);
		t1.DateTime(driver);
		t1.SelectCar(driver);
		t1.CarNameAndPrice(driver);
		sc1.Screenshot(driver);
	
	}
	
	@AfterTest
	public void f3()
	{
		driver.quit();  //Used to exit the browser
	}
}
