package POMRepos;

public class Homepage {
	
//Xpath of 1-way radio button
public static String Oneway= "//label[@class='margin-left-20px']/span"; 
//Xpath of From textbox
public static String FromClick= "//input[@id='fromCityList']"; 
//Xpath to choose From destination
public static String FromDestination ="//button[@id='ngb-typeahead-0-0']"; 
//Xpath of To textbox
public static String ToClick= "//div[@class='col-10 col tocityHolder']/input"; 
//Xpath to choose To destination
public static String ToDestination ="//span[@class='ngb-highlight']"; 
//Xpath for next month button
public static String CalendarClick = "//a[@class='ui-datepicker-next ui-corner-all']/span"; 
//Xpath to click on calendar
public static String Calendar = "//span[@class='ng-tns-c11-1 ui-calendar']/input";
//Xpath of the date chosen
public static String DatePick= "//table[@class='ui-datepicker-calendar ng-tns-c11-1']/tbody/tr[2]/td[7]/a"; 
//Xpath of picking the time
public static String Time= "//select[@id='pickUpTime']";
//Xpath of Select Car button
public static String SelectCarBtn ="//div[@class='buttonBlock']/button"; 
}
