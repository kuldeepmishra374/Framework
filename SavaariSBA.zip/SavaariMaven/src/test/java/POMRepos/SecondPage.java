package POMRepos;

public class SecondPage {
//Xpath to obtain the second car name
public static String name= "//div[@class='rateUIDesktop carListContent7 row carListContent carListBlock']/div/div[2]/div/span"; 
//Xpath to obtain the second car price
public static String price= "//div[@class='rateUIDesktop carListContent7 row carListContent carListBlock']/div[3]/div[2]/span"; 
}
