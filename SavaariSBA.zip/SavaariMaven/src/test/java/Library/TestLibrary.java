package Library;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import POMRepos.Homepage;
import POMRepos.SecondPage;
import Utils.Excel;


public class TestLibrary {
	//Initialising the webdriver
	WebDriver driver;
	//One way round trip selected
	public void OneWay(WebDriver driver)
	{
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //The Implicit Wait in Selenium is used to tell the web driver to wait for a certain amount of time
		 driver.findElement(By.xpath(Homepage.Oneway)).click();
	}
	
	//Pick up values Coimbatore and Chennai given to From and To textboxes respectively
	public void FromTo(WebDriver driver) throws IOException 
	{
		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    String st1= Excel.getValue1();  //Obtaining the value from Excel and storing it in the string 
		    String st2= Excel.getValue2();
		    driver.findElement(By.xpath(Homepage.FromClick)).sendKeys(st1);  //String value entered into the textbox
		    driver.findElement(By.xpath(Homepage.FromDestination)).click();  
		    driver.findElement(By.xpath(Homepage.ToClick)).sendKeys(st2);
		    driver.findElement(By.xpath(Homepage.ToDestination)).click();
	}
	
	//Pick up date and time entered as Future date and time
	public void DateTime(WebDriver driver) throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); // Implicit wait
		driver.findElement(By.xpath(Homepage.Calendar)).click(); 
		driver.findElement(By.xpath(Homepage.CalendarClick)).click();
																		
		Thread.sleep(2000);
		driver.findElement(By.xpath(Homepage.DatePick)).click(); 

		Select s = new Select(driver.findElement(By.xpath(Homepage.Time))); // Select class for dropdown
		s.selectByIndex(5); // Selecting by index
	}
	
	//Select car button clicked
	public void SelectCar(WebDriver driver)
	{
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		 driver.findElement(By.xpath(Homepage.SelectCarBtn)).click();
	}
	
	//Second car name and price is printed
	public void CarNameAndPrice(WebDriver driver) throws IOException 
	{
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String st1 = driver.findElement(By.xpath(SecondPage.name)).getText();
		String st2 = driver.findElement(By.xpath(SecondPage.price)).getText();
		System.out.println("The name and the price of the second car is:" +st1 +" " +st2);
		
		
	}
	
}
