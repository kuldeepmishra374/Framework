package example.example.pages;

import java.util.ArrayList;
import example.example.util.*;
import jdk.jfr.internal.Logger;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

/**
 * The Class represents FacebookLoginPage.
 *
 * @author KuldeepMishra
 */
public class DemoriaLogin extends BasePage{
	
	/** The email input. */
	@FindBy(xpath = "//input[@name='bitmeup-username']")
	private WebElement emailInput;

	@FindBy(xpath = "//input[@name='bitmeup-password']")
	private WebElement pass;

	@FindBy(xpath = "//*[@id=\"form.login.container\"]/table/tbody/tr[1]/td[2]/div")
	private WebElement Login;
	
	@FindBy(xpath = "//span[contains(text(),'enter kingdom')]")
	private WebElement Enter_Kingdom;
	
	@FindBy(id = "langselect")
	private WebElement LanguageSelection;
	
	@FindBy(xpath = "//td[contains(text(),'English')]")
			//*[@id=\"tr-lang-sel\"]/tbody/tr[1]/td[1]/div/table/tbody/tr/td[4]/text()")
	private WebElement English;
	
	@FindBy(xpath = "//*[@id='tr-user-knight']/div[2]")
	private WebElement YourGuards;
	
	@FindBy(xpath = "//span[contains(@id,'overview-knight-cd')]")
	private WebElement Duration;
	
	@FindBy(xpath = "//div[contains(text(),'complete mission')]")
	private WebElement CompleteMission;
	
	@FindBy(xpath = "//div[@id='header-missions' and contains(text(),'Missions')]")
	private WebElement Mission;
	
	
	/**
	 * Instantiates a new Demoria login page.
	 *
	 * @param driver the driver
	 */
	public DemoriaLogin(WebDriver driver) {
		super(driver);
	}

	
	public List<String> SortTheDuration(By xpath)
	{
		ArrayList<String> obtainedList = new ArrayList<>(); 
		List<WebElement> elementList= driver.findElements(xpath);
		for(WebElement we:elementList){
		   obtainedList.add(we.getText());
		}
		ArrayList<String> sortedList = new ArrayList<>();   
		for(String s:obtainedList){
		sortedList.add(s);
		}
		Collections.sort(sortedList);
		return sortedList;
	}
	public void AcceptAll(List<String> All) throws InterruptedException
	{
		
		WebElement Accept=driver.findElement(By.xpath("//span[contains(text(),'"+ All.get(0) +"')]/parent::div/following-sibling::div"));
		Accept.click();
		
		
		 Thread.sleep(5000);
		 System.out.println(Accept);
		}
	public void DurationTest(String email,String passw) throws InterruptedException
	{
		new WebDriverWait(driver, 60).ignoring(StaleElementReferenceException.class)
		  .until(ExpectedConditions.visibilityOf(emailInput));
		emailInput.sendKeys(email);
		LoggerUtil.log("Email Entered ");
		pass.sendKeys(passw);
		LoggerUtil.log("Password Entered ");
		Login.click();
		LoggerUtil.log("Sign in ...!");
		  Enter_Kingdom.click(); 
		  System.out.print("Enter Kingdom");
		  LoggerUtil.log("Entered into Kingdom");
		  	 
		 Thread.sleep(5000);	
		 driver.findElement(By.xpath("//*[@id='da-chat-min']")).click();
		 Thread.sleep(5000);	
		  WebElement frame=driver.findElement(By.xpath("//*[@id='gameframe']"));
		  new WebDriverWait(driver, 60).ignoring(StaleElementReferenceException.class)
		  .until(ExpectedConditions.visibilityOf(frame));
		  driver.switchTo().frame(frame);
		  
		     new WebDriverWait(driver, 60).ignoring(StaleElementReferenceException.class)
			  .until(ExpectedConditions.visibilityOf(YourGuards)); 
			  YourGuards.click();
			  
			  
			  
			  
			  LoggerUtil.log("Gettig the Guard List"); 
			  Thread.sleep(3000);
			  List<String>  Guards=SortTheDuration(By.xpath("//div[@id='content-overview']/center/div/div[3]/div/table/tbody/tr/td/span")); 
			  for(String guard:Guards)
			  {
				  WebElement guards=driver.findElement(By.xpath("//span[contains(text(),'"+ guard +"')]/parent::td/parent::tr/parent::tbody/parent::table/parent::div/parent::div/preceding-sibling::div[1]/table/tbody/tr[4]/td/div/span"));
			     
				  if(guards.getText().contains("Action"))
			      {
					  System.out.println(guards.getText());
			    	  driver.findElement(By.xpath("//div[@id='content-overview']/center/div/div[3]/descendant::td/span[contains(text(),'"+ guard +"')]")).click();
					   LoggerUtil.log("Guard Selected");
					   if(Mission.isDisplayed() && !CompleteMission.isDisplayed())
					   {
						   
						   Mission.click(); 
						   Thread.sleep(3000);
					   }
					   
					   else if(Mission.isDisplayed() && CompleteMission.isDisplayed() )
						   CompleteMission.click();
					   
						LoggerUtil.log("Completed Mission Tab Clicked");
						
					     List <String> Mission=SortTheDuration(By.xpath(
						  "//span[@style='font-size:14px;']/preceding-sibling::br/following-sibling::span"
						  ));
						  System.out.println(Mission);
						  LoggerUtil.log("Selecting mission with minimum time duration ");
						  AcceptAll(Mission);
						  Thread.sleep(3000);
						  new WebDriverWait(driver, 60).ignoring(StaleElementReferenceException.class)
						  .until(ExpectedConditions.visibilityOf(YourGuards));
						  YourGuards.click();  
						  Thread.sleep(10000);
			       }
				  else if(guards.getText().contains("Mission") 
			       &&
			       driver.findElement(By.xpath("//span[contains(text(),'"+ guard +"')]/parent::td/parent::tr/parent::tbody/parent::table/parent::div/parent::div/preceding-sibling::div[1]/table/tbody/tr[4]/td/div/span[2]")).getText().equals("--:--:--"))
				  {  System.out.println(guards.getText());
			    	        driver.findElement(By.xpath("//div[@id='content-overview']/center/div/div[3]/descendant::td/span[contains(text(),'"+ guard +"')]")).click();
						   LoggerUtil.log("Guard Selected");
						   if(Mission.isDisplayed() && !CompleteMission.isDisplayed())
						   {
							   
							   Mission.click(); 
							   Thread.sleep(3000);
						   }
						   
						   else if(Mission.isDisplayed() && CompleteMission.isDisplayed() )
							   CompleteMission.click();
						   
							LoggerUtil.log("Completed Mission Tab Clicked");
							
						     List <String> Mission=SortTheDuration(By.xpath(
							  "//span[@style='font-size:14px;']/preceding-sibling::br/following-sibling::span"
							  ));
							  System.out.println(Mission);
							  LoggerUtil.log("Selecting mission with minimum time duration ");
							  AcceptAll(Mission);
							  Thread.sleep(3000);
							  new WebDriverWait(driver, 60).ignoring(StaleElementReferenceException.class)
							  .until(ExpectedConditions.visibilityOf(YourGuards));
							  YourGuards.click();  
							  Thread.sleep(10000);
			    	   }
			      else 
			    	  continue;
				  }
			
	}
			 
}
