package example.example.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

import example.example.context.WebDriverContext;
import example.example.factory.PageinstancesFactory;
import example.example.pages.DemoriaLogin;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * The Class FaceBookLoginTest.
 *
 * @author KuldeepMishra
 */

@Test(testName = "Demoria GamingApp login test", description = "Demoria login test")
public class DemoriaTestCases extends BaseTest {
	
	@Test(invocationCount=1)
	public void DemoriaLoginTest() throws InterruptedException {
		WebDriverManager.chromedriver().setup(); ChromeOptions ops = new
		ChromeOptions(); ops.addArguments("disable-infobars"); driver = new
		ChromeDriver(ops); driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebDriverContext.setDriver(driver);

		driver.get("https://damoria.bitmeup.com/");
		DemoriaLogin dm_login = PageinstancesFactory.getInstance(DemoriaLogin.class);
		dm_login.DurationTest("soso_@web.de", "D_123456");
		Assert.assertTrue(true, "Login Passed : Test Passed");
		Thread.sleep(60000);
	}
}
