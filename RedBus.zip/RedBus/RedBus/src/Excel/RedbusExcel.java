package Excel;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
public class RedbusExcel {
	WebDriver driver;
	public static String Value1;
		public static String Value2;
		
		public static String getvalue1() throws Exception
		{
		FileInputStream fi = new FileInputStream("C:\\Users\\834075\\Desktop\\Project\\Pratice2\\redbus.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fi);
		XSSFSheet sh = wb.getSheet("Sheet1");
		
		Value1 = sh.getRow(0).getCell(0).getStringCellValue();
		System.out.println("FirstValue is "+Value1);
		return Value1;
		
	 }
		public static  String getvalue2() throws IOException
		{
			
		
		FileInputStream fi = new FileInputStream("C:\\Users\\834075\\Desktop\\Project\\Pratice2\\redbus.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fi);
		XSSFSheet sh = wb.getSheet("Sheet1");
		
		Value2 = sh.getRow(0).getCell(1).getStringCellValue();
		System.out.println("FirstValue is "+Value1);
		return Value2;	   

	}
}


