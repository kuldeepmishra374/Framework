package RedbusTest;

import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Excel.RedbusExcel;

import Redbus.HomePageRedbus;
import Redbus.InsidePage;

public class TestSearch {
	
	String driverPath1 = "C:\\Users\\834075\\Desktop\\0.24.0\\2.41Chrome\\chromedriver.exe";
	String driverPath2 = "C:\\Users\\834075\\Desktop\\0.24.0\\geckodriver-v0.24.0-win64\\geckodriver.exe";
	WebDriver driver;
	 HomePageRedbus objhomepage;
	 InsidePage objinsidepage;

	@BeforeTest
	public void setup(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1 for chrome and 2 for firefox ");
		int a;
	      a=sc.nextInt();
		  if(a==1){
		System.setProperty("webdriver.chrome.driver", driverPath1);
	        
	        driver = new ChromeDriver();
	       
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	        driver.get("https://www.redbus.in/");
	        driver.manage().window().maximize();
		  }
	        else{
	        	System.setProperty("webdriver.gecko.driver", driverPath2);
	        	driver = new FirefoxDriver();
	        	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		        driver.get("https://www.redbus.in/");
		        driver.manage().window().maximize();
	        }
	    }
	
	@Test
	public void search_and_click_bus() throws IOException, Exception {
		objhomepage= new HomePageRedbus(driver);
		objhomepage.clickonsearch(RedbusExcel.getvalue1(),RedbusExcel.getvalue2());
		
		objinsidepage=new InsidePage(driver);
		objinsidepage.click_AC();
		
		 boolean Book_Visible = driver.findElement(By.xpath("//*[@id=\"11037352\"]/div/div[1]/div[1]/div[1]/div[1]")).isDisplayed();
		    if(Book_Visible){
		    	objinsidepage.snapshot();
		    }	
		
		
		
		System.out.println("BusName:"+objinsidepage.getnameofbus());
		System.out.println("Price:Rs"+objinsidepage.getPriceofbus());
	}
	@AfterTest
	public void closeB(){
		objinsidepage.close();
	}
}
