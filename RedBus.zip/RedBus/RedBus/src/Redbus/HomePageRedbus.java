package Redbus;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePageRedbus {

		WebDriver driver;
	    By userfrom = By.id("src");
	    By clickuserfrom= By.xpath("//*[@id='search']/div/div[1]/div/ul/li");
	    By userto=By.id("dest");
	    By clickuserto= By.xpath("//*[@id='search']/div/div[2]/div/ul/li");
	    By onwardDateclick=By.xpath("//*[@id='search']/div/div[3]/div/label");
	    By onwardDateSelect=By.xpath("//*[@id='rb-calendar_onward_cal']/table/tbody/tr[7]/td[4]");
	    By searchButton=By.id("search_btn");
	   
	    public HomePageRedbus(WebDriver driver){
	    	this.driver = driver;
	    }
	    public void setfrom(String strfrom){
	    	 driver.findElement(userfrom).sendKeys(strfrom);
	    }
	    public void fclickuserfrom(){
	    	 driver.findElement(clickuserfrom).click();
	    }
	    public void setto(String strto){
	    	 driver.findElement(userto).sendKeys(strto);
	    }
	    public void fclickuserto(){
	    	 driver.findElement(clickuserto).click();
	    }
	    public void clickonwardDate(){
	    	 driver.findElement(onwardDateclick).click();
	    }
	    public void SelectonwardDate(){
	    	 driver.findElement(onwardDateSelect).click();
	    }
	    public void clickSearch(){
	    	 driver.findElement(searchButton).click();
	    }
	    public void clickonsearch(String strfrom,String strto){
	        
	        this.setfrom(strfrom);
	        this.setto(strto);
	        this.fclickuserto();
	        this.fclickuserfrom();        
	        this.clickonwardDate();
	        this.SelectonwardDate();
	        this.clickSearch();
	    }

	}

