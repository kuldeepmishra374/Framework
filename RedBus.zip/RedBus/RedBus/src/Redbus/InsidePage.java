package Redbus;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.google.common.io.Files;

public class InsidePage {
	WebDriver driver;
	By clickAc=By.xpath("//*[@id='filter-block']/div/div[2]/ul[3]/li[3]/label[1]");	
	By secondBusName=By.xpath("//*[@id='11037352']/div/div[1]/div[1]/div[1]/div[1]");
	By secondBusPrice=By.xpath("//*[@id='11037352']/div/div[1]/div[1]/div[6]/div/div/span");
	
	 public InsidePage(WebDriver driver){
	    	this.driver = driver;
	    }
	 public void click_AC(){
		 driver.findElement(clickAc).click();
	 }
	 public String getnameofbus(){

	     return    driver.findElement(secondBusName).getText();

	    }
	 public String getPriceofbus(){

	     return    driver.findElement(secondBusPrice).getText();

	    }
	 public void snapshot() throws IOException{
		 
		  
		 TakesScreenshot snap = (TakesScreenshot)driver;
			File actual =  snap.getScreenshotAs(OutputType.FILE);
			File destFile = new File("C:\\Users\\834075\\Desktop\\Project\\Pratice2\\src\\ss/RedbusS.png");
			Files.copy(actual, destFile);
	 }
	 public void close(){
		 driver.close();
	 }
}
